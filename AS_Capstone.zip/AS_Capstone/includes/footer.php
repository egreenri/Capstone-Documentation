    <footer>
        <hr class="m-0 text-secondary opacity-100 border border-secondary border-1">
        <div class="p-1">
    </footer>
</body>
</html>